package multitools;

import java.sql.ResultSet;
import java.util.HashMap;

public class JsonUtilities {
	
	public JsonUtilities() {
	
	}
	
	public Object parse( String jsonText, String className) {
		Object object = null;

		return object;
	}
	
	
	public String parse(Object object) {

		return "";
	}

	public String parse( ResultSet resultSet) {

		return "";
	}
	
	public String parse( HashMap<String, String> hashMap) {

		return "";
	}
	
	public String parse( String[]  values) {

		return "";
	}
	
	public String parse( String[][]  values) {

		return "";
	}	
}
