package model;

public enum Status {
	ABERTO,
	EM_PREPARO,
	A_CAMINHO,
	ENTREGUE,
	CANCELADO,
}