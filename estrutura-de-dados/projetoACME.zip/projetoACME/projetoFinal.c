#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "projetoFinal.h"

struct elemento{
    CLIENTE dados;
    struct elemento *prox;
};

typedef struct elemento ELEM; // nomea��o serve apenas para esse arquivo

Lista *criaLista(){ // Cria a lista e aloca memoria
    Lista *li;
    li = (Lista*) malloc(sizeof(Lista));
    if(li != NULL){
        *li = NULL;
    }

    return li;
}

void apagaLista(Lista *li){ // Faz a libera��o da memoria usada
    if(li != NULL){
        ELEM *no;
        while((*li) != NULL){
            no = *li;
            *li = (*li)->prox;
            free(no);
        }
        free(li);
    }
}

int tamLista(Lista *li){ // Retorna o tamanho da lista
    if(li == NULL){
        return 0;
    }
    int acum = 0;
    ELEM *no = *li;
    while(no != NULL){
        acum++;
        no = no->prox;
    }
    return acum;
}

int listaCheia(Lista *li){ // Avisa se a lista est� cheia
    return 0;
}

int listaVazia(Lista *li){ // Avisa se a lista est� vazia
    if(li == NULL){
        return 1;
    }
    if(*li == NULL){
        return 1;
    }
    return 0;
}


int insere_lista_ordenada(Lista *li, CLIENTE al){ // Insere elementos ordenadamente
    if(li == NULL){
        return 0;
    }

    ELEM *no = (ELEM*) malloc(sizeof(ELEM));
    if(no == NULL){
        return 0;
    }
    no->dados = al;
    if(listaVazia(li)){
        no->prox = (*li);
        *li = no;
        return 1;
    } else {
        ELEM *ant, *atual = *li;
        while(atual != NULL && atual->dados.codigo < al.codigo){
            ant = atual;
            atual = atual->prox;
        }
        if(atual == *li){ // insere se estiver na primeira pos
            no->prox = (*li);
            *li = no;
        } else { // insere em qualquer pos
            no->prox = ant->prox;
            ant->prox = no;
        }

        return 1;
    }
}


int remove_lista(Lista *li, int mat){ // Remove elemento pelo codigo
    if(li == NULL){
        return 0;
    }
    ELEM *ant, *no = *li;
    while(no != NULL && no->dados.codigo != mat){
        ant = no;
        no = no->prox;
    }

    if(no == NULL){
        return 0;
    }
    if(no == *li){
        *li = no->prox;
    } else {
        ant->prox = no->prox;
    }
    free(no);
    return 1;
}

int consulta_lista_pos(Lista *li, int posicao, CLIENTE *al){
    if(li == NULL || posicao <= 0){
        return 0;
    }
    ELEM *no = *li;
    int i = 1;
    // percorre a lista com i a procura do elemento
    while(no != NULL && i < posicao){
        no = no->prox;
        i++;
    }

    // trata-se da lista vazia, ou n�o encontrou o elemento
    if(no == NULL){
        return 0;
    } else{
    // se no != de NULL, ent�o encontrou o elemento
        *al = no->dados;
        return 1;
    }
}

int consulta_lista_id(Lista *li, int id, CLIENTE *al){
    if(li == NULL){
        return 0;
    }
    ELEM *no = *li;
    while(no != NULL && no->dados.codigo != id){
        no = no->prox;
    }
    if(no == NULL){
        return 0;
    } else {
        *al = no->dados;
        return 1;
    }
}

struct cliente insereDados() {
    struct cliente al;

    printf("\n\n\tNovo cliente...\n\n");

    printf("Digite o codigo: ");
    scanf("%d", &al.codigo);

    // Limpa o buffer de entrada
    while (getchar() != '\n');

    printf("Digite o nome: ");
    fgets(al.nome, sizeof(al.nome), stdin);
    al.nome[strcspn(al.nome, "\n")] = '\0';
    for (int i = 0; al.nome[i]; i++) {
        al.nome[i] = tolower(al.nome[i]);
    }

    printf("Digite o nome da empresa: ");
    fgets(al.empresa, sizeof(al.empresa), stdin);
    al.empresa[strcspn(al.empresa, "\n")] = '\0';

    printf("Digite o departamento: ");
    fgets(al.departamento, sizeof(al.departamento), stdin);
    al.departamento[strcspn(al.departamento, "\n")] = '\0';

    printf("Digite o telefone: ");
    fgets(al.telefone, sizeof(al.telefone), stdin);
    al.telefone[strcspn(al.telefone, "\n")] = '\0';

    printf("Digite o celular: ");
    fgets(al.celular, sizeof(al.celular), stdin);
    al.celular[strcspn(al.celular, "\n")] = '\0';

    printf("Digite o email: ");
    fgets(al.email, sizeof(al.email), stdin);
    al.email[strcspn(al.email, "\n")] = '\0';

    return al;
}


struct cliente editaDados(CLIENTE al){

    printf("Digite o codigo: ");
    scanf("%d", &al.codigo);

    // Limpa o buffer de entrada
    while (getchar() != '\n');

    printf("Digite o nome: ");
    fgets(al.nome, sizeof(al.nome), stdin);
    al.nome[strcspn(al.nome, "\n")] = '\0';
    for (int i = 0; al.nome[i]; i++) {
        al.nome[i] = tolower(al.nome[i]);
    }

    printf("Digite o nome da empresa: ");
    fgets(al.empresa, sizeof(al.empresa), stdin);
    al.empresa[strcspn(al.empresa, "\n")] = '\0';

    printf("Digite o departamento: ");
    fgets(al.departamento, sizeof(al.departamento), stdin);
    al.departamento[strcspn(al.departamento, "\n")] = '\0';

    printf("Digite o telefone: ");
    fgets(al.telefone, sizeof(al.telefone), stdin);
    al.telefone[strcspn(al.telefone, "\n")] = '\0';

    printf("Digite o celular: ");
    fgets(al.celular, sizeof(al.celular), stdin);
    al.celular[strcspn(al.celular, "\n")] = '\0';

    printf("Digite o email: ");
    fgets(al.email, sizeof(al.email), stdin);
    al.email[strcspn(al.email, "\n")] = '\0';

    return al;

}

void geraRelatorio(Lista *li) {
    if(listaVazia(li)){
        printf("\nErro: Lista vazia!\n");
    } else {
        ELEM *no = *li;
        int i = 1;

        while (no != NULL) {
            CLIENTE cl = no->dados;

            printf("\n\n\t\tCliente %d\n\n", i);
            imprimeDados(cl);
            no = no->prox;
            i++;
        }
    }

}

void relatorioIndividualNome(Lista *li) {
    if (li == NULL || *li == NULL) {
        printf("Erro: Lista vazia\n");
        return;
    }

    char nome[50];
    printf("\nDigite o nome: ");
    scanf(" %s", nome);

    int i;
    for (i = 0; nome[i]; i++) {
        nome[i] = tolower(nome[i]);
    }

    CLIENTE cl;
    ELEM *no = *li;
    int acum = 0;

    i = 1;
    while (no != NULL) {
        if (strcmp(no->dados.nome, nome) == 0) {
            cl = no->dados;
            printf("\n\n\t\tCliente encontrado %d\n\n", i);
            imprimeDados(cl);
            i++;
        } else {
            acum++;
        }

        no = no->prox;
    }

    if(acum == tamLista(li)){
        printf("Nome nao encontrado\n");
    }

}


void relatorioIndividualId(Lista *li) {
    int i, x;
    printf("\nDigite o codigo de identificacao: ");
    scanf("%d", &i);
    CLIENTE cl;
    x = consulta_lista_id(li, i, &cl);
    if (x) {
        imprimeDados(cl);
    } else {
        printf("\nNao foi possivel consultar a posicao desejada\nMotivos: O codigo fornecido nao e valido, o cliente pode ter sido excluido anteriormente, a lista pode estar vazia, etc\n");
    }
}

void imprimeDados(CLIENTE cl){
        printf("Codigo......: %d\n", cl.codigo);
        printf("Nome........: %s\n", cl.nome);
        printf("Empresa.....: %s\n", cl.empresa);
        printf("Departamento: %s\n", cl.departamento);
        printf("Telefone....: %s\n", cl.telefone);
        printf("Celular.....: %s\n", cl.celular);
        printf("E-mail......: %s\n", cl.email);
}

void editaCli(Lista *li) {
   ELEM* edita = *li;
    int codigo;
    char resposta;
    printf("\nDigite o codigo de identificacao: ");
    scanf("%d", &codigo);

    while (edita != NULL) {
        if (edita->dados.codigo == codigo) {
                edita->dados = editaDados(edita->dados);
                printf("\nModificacoes salvas!\n");
                return;
        }
        edita = edita->prox;
    }
        printf("\nCliente com o codigo %d n�o encontrado na lista.\n", codigo);
}


void exibirMenu() { // Fun��o criada somente para a exibi��o do menu
    printf("\nDigite a opcao desejada conforme as seguintes:\n");
    printf("0 - Sair do programa;\n");
    printf("1 - Insercao de novo contato;\n");
    printf("2 - Gerar e exibir relatorio de contatos;\n");
    printf("3 - Gerar e exibir relatorio individual com busca por identificador;\n");
    printf("4 - Gerar e exibir relatorio com busca por nome;\n");
    printf("5 - Edicao de dados do contato, escolhido por identificador;\n");
    printf("6 - Remover contato, escolhido por identificador;\n");
    printf("\nOpcao desejada: ");
}


void menu(int codigo, Lista *li) {
    /* Fun��o criada para dar o poder de escolha de uma das op��es
    do menu, a partir da escolha, s�o chamadas as fun��es espec�ficas
    para cada caso */
    char opcao;
    struct cliente al, novoCliente; // Assumindo que al � uma vari�vel do tipo struct cliente
    int x;

    do {
        exibirMenu();
        scanf(" %c", &opcao);
        int cod;

        switch (opcao) {
            case '0':
                printf("\n\t\tPrograma encerrando...\n");
                break;

            case '1':
                system("cls");
                novoCliente = insereDados();
                insere_lista_ordenada(li, novoCliente);
                break;

            case '2':
               // printf("\n\t\tGerando relatorio de contatos...\n");
                system("cls");
                geraRelatorio(li);
                break;

            case '3':
                system("cls");
                printf("\n\t\tGerando relatorio individual - Busca por Codigo\n");
                relatorioIndividualId(li);
                break;

            case '4':
                system("cls");
                printf("\n\t\tGerando relatorio individual - Busca por Nome\n");
                relatorioIndividualNome(li);
                break;

            case '5':
                system("cls");
                printf("\n\t\tEdicao de Contatos\n");
                editaCli(li);
                break;

            case '6':
                printf("Digite o codigo de identificacao do cliente que deseja excluir: ");
                scanf("%d", &cod);
                x = remove_lista(li, cod);
                if(x){
                    printf("Removido o elemento com sucesso!\n");
                } else {
                    printf("Nao foi possivel remover o elemento!\n");
                }
                break;

            default:
                printf("Selecione uma opcao valida\n");
        }

    } while (opcao != '0');
}

int gravaArquivo(Lista *li, FILE *f) {
    if (li == NULL) {
        return 0; // Lista vazia ou nula
    }

    ELEM *no = (ELEM*) malloc(sizeof(ELEM));
    if(no == NULL){
        return 0;
    }
    no = *li;
    while(no != NULL) {
        fwrite(no, sizeof(ELEM), 1, f);
        no = no->prox; // Corrigido para mover para o pr�ximo elemento ap�s a grava��o
        printf("Gravando");
    }

    return 1; // Sucesso
}
