package model;

public interface ModelInterface {
	public Integer getId();
    public void setId(Integer id);
}
