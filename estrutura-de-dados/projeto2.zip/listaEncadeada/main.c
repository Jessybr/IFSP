#include <stdio.h>
#include <stdlib.h>
#include "listaLigada.h"

int main()
{
    FILE *f;
    f = fopen("arquivo.txt", "w+");

    if(f == NULL){ // Garante que o arquivo foi aberto corretamente
        printf("\t\tErro ao abrir o arquivo!\n\n");
        system("pause");
        exit(1);
    }

    Lista *li; // ponteiro para ponteiro que est� no arquivo listaLigada.h
    li = criaLista();
    int x = 0;
    printf("\t\tBem-vindo(a) a empresa ACME S.A\n\n");

    // Vari�veis a seguir criadas para a busca:
    int codigo = 0;
    char nome[30];

    menu(codigo, li);
    gravaArquivo(li, f);

    fclose(f);
    return 0;
}

