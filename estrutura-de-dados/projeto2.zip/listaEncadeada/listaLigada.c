#include <stdio.h>
#include <stdlib.h>
#include "listaLigada.h"

struct elemento{
    CLIENTE dados;
    struct elemento *prox;
};

typedef struct elemento ELEM; // nomea��o serve apenas para esse arquivo

Lista *criaLista(){ // Cria a lista e aloca memoria
    Lista *li;
    li = (Lista*) malloc(sizeof(Lista));
    if(li != NULL){
        *li = NULL;
    }

    return li;
}

void apagaLista(Lista *li){ // Faz a libera��o da memoria usada
    if(li != NULL){
        ELEM *no;
        while((*li) != NULL){
            no = *li;
            *li = (*li)->prox;
            free(no);
        }
        free(li);
    }
}

int tamLista(Lista *li){ // Retorna o tamanho da lista
    if(li == NULL){
        return 0;
    }
    int acum = 0;
    ELEM *no = *li;
    while(no != NULL){
        acum++;
        no = no->prox;
    }
    return acum;
}

int listaCheia(Lista *li){ // Avisa se a lista est� cheia
    return 0;
}

int listaVazia(Lista *li){ // Avisa se a lista est� vazia
    if(li == NULL){
        return 1;
    }
    if(*li == NULL){
        return 1;
    }
    return 0;
}


int insere_lista_ordenada(Lista *li, CLIENTE al){ // Insere elementos ordenadamente
    if(li == NULL){
        return 0;
    }

    ELEM *no = (ELEM*) malloc(sizeof(ELEM));
    if(no == NULL){
        return 0;
    }
    no->dados = al;
    if(listaVazia(li)){
        no->prox = (*li);
        *li = no;
        return 1;
    } else {
        ELEM *ant, *atual = *li;
        while(atual != NULL && atual->dados.codigo < al.codigo){
            ant = atual;
            atual = atual->prox;
        }
        if(atual == *li){ // insere se estiver na primeira pos
            no->prox = (*li);
            *li = no;
        } else { // insere em qualquer pos
            no->prox = ant->prox;
            ant->prox = no;
        }

        return 1;
    }
}


int remove_lista(Lista *li, int mat){ // Remove elemento pelo codigo
    if(li == NULL){
        return 0;
    }
    ELEM *ant, *no = *li;
    while(no != NULL && no->dados.codigo != mat){
        ant = no;
        no = no->prox;
    }

    if(no == NULL){
        return 0;
    }
    if(no == *li){
        *li = no->prox;
    } else {
        ant->prox = no->prox;
    }
    free(no);
    return 1;
}

int consulta_lista_pos(Lista *li, int posicao, CLIENTE *al){
    if(li == NULL || posicao <= 0){
        return 0;
    }
    ELEM *no = *li;
    int i = 1;
    // percorre a lista com i a procura do elemento
    while(no != NULL && i < posicao){
        no = no->prox;
        i++;
    }

    // trata-se da lista vazia, ou n�o encontrou o elemento
    if(no == NULL){
        return 0;
    } else{
    // se no != de NULL, ent�o encontrou o elemento
        *al = no->dados;
        return 1;
    }
}

int consulta_lista_mat(Lista *li, int mat, CLIENTE *al){
    if(li == NULL){
        return 0;
    }
    ELEM *no = *li;
    while(no != NULL && no->dados.codigo != mat){
        no = no->prox;
    }
    if(no == NULL){
        return 0;
    } else {
        *al = no->dados;
        return 1;
    }
}

struct cliente insereDados(){

    struct cliente al;
    printf("\n\n\tNovo cliente...\n\n");
    printf("Digite o codigo: ");
    scanf("%d", &al.codigo);

    printf("Digite o nome: ");
    getchar();
    fgets(al.nome, sizeof(al.nome), stdin);
    al.nome[strcspn(al.nome, "\n")] = '\0';

    printf("Digite o nome da empresa: ");
    getchar();
    fgets(al.empresa, sizeof(al.empresa), stdin);
    al.empresa[strcspn(al.empresa, "\n")] = '\0';

    printf("Digite o departamento: ");
    getchar();
    fgets(al.departamento, sizeof(al.departamento), stdin);
    al.departamento[strcspn(al.departamento, "\n")] = '\0';

    printf("Digite o telefone: ");
    getchar();
    fgets(al.telefone, sizeof(al.telefone), stdin);
    al.telefone[strcspn(al.telefone, "\n")] = '\0';


    printf("Digite o celular: ");
    getchar();
    fgets(al.celular, sizeof(al.celular), stdin);
    al.celular[strcspn(al.celular, "\n")] = '\0';

    printf("Digite o email: ");
    getchar();
    fgets(al.email, sizeof(al.email), stdin);
    al.email[strcspn(al.email, "\n")] = '\0';

    return al;

}

void imprime_dados(Lista *li) {/*
    int i, x;
    struct cliente dados_aluno;
        x = consulta_lista_pos(li, i, &dados_aluno);
        if(x) {
            printf("\nConsulta por posicao realizada!\n");
            printf("Matricula: %d\n", dados_aluno.matricula);
            printf("Nota 1: %.2f\n", dados_aluno.n1);
            printf("Nota 2: %.2f\n", dados_aluno.n2);
            printf("Nota 3: %.2f\n", dados_aluno.n3);
        } else {
            printf("\nNao foi possivel consultar a posicao desejada\n");
        }*/
}

void exibirMenu() { // Fun��o criada somente para a exibi��o do menu
    printf("\nDigite a opcao desejada conforme as seguintes:\n");
    printf("0 - Sair do programa;\n");
    printf("1 - Insercao de novo contato;\n");
    printf("2 - Gerar e exibir relatorio de contatos;\n");
    printf("3 - Gerar e exibir relatorio individual com busca por identificador;\n");
    printf("4 - Gerar e exibir relatorio com busca por nome;\n");
    printf("5 - Edicao de dados do contato, escolhido por identificador;\n");
    printf("6 - Remover contato, escolhido por identificador;\n");
    printf("\nOpcao desejada: ");
}


void menu(int codigo, Lista *li) {
    /* Fun��o criada para dar o poder de escolha de uma das op��es
    do menu, a partir da escolha, s�o chamadas as fun��es espec�ficas
    para cada caso */
    char opcao;
    struct cliente al, novoCliente; // Assumindo que al � uma vari�vel do tipo struct cliente
    int x;

    do {
        exibirMenu();
        scanf(" %c", &opcao);

        switch (opcao) {
            case '0':
                printf("Programa encerrando...\n");
                break;

            case '1':
                novoCliente = insereDados();
                insere_lista_ordenada(li, novoCliente);
                system("cls");
                break;

            case '2':

                break;

            case '3':

                break;

            default:
                printf("Selecione uma opcao valida\n");
        }

    } while (opcao != '0');
}

int gravaArquivo(Lista *li, FILE *f) {
    if (li == NULL) {
        return 0; // Lista vazia ou nula
    }

    ELEM* no = li;
    while (no != NULL) {
        fwrite(no, sizeof(ELEM), 1, f);
        no = no->prox; // Corrigido para mover para o pr�ximo elemento ap�s a grava��o
        printf("Gravando");
    }

    return 1; // Sucesso
}
